// sqlite.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Proiect de echipa realziat de: Ghita Valentin, Gogoasa Cristian, Ionel Teodor
// p.s.: am folosit in principal vector din libraria stl intrucat sunt si ei alocati dinamic la baza
// i-am folosit mostly pentru ease of use dar avem si un camp alocat dinamic in clasa Entry
// si in functia string* split_string_into_words(string userInput) si functiile de read_content_... read_headers_...

#include "clase_si_functii.h"
#include <iostream>

using namespace std;

int main(int argsc, char* argsv[])
{
    menu(argsc, argsv);
    return 0;
}
